<<<<<<< HEAD
# WindowsGSM.SCUM
=======
# WindowsGSM.SCUM

A plugin to run and manage SCUM Dedicated Servers using WindowsGSM.

## Features

- Easy install via SteamCMD
- Start/Stop server
- Console output
- Build/version detection

## Installation

1. Clone/download this repo
2. Build the `.csproj` with Visual Studio
3. Copy the compiled `.dll` to `WindowsGSM/plugins/`

## License

MIT
>>>>>>> 8f52ef1 (Initial commit of SCUM plugin)
